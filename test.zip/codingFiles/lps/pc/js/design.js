// Viewport Object
(function () {
    var window = this,
        document = window.document,
        documentElement = document.documentElement,
        addEvent = window.addEvent || function (element, type, listener) {
            if (element.addEventListener) {
                element.addEventListener(type, listener, false);
            } else if (element.attachEvent) {
                element.attachEvent('on' + type, listener);
            }
        };

    window.viewport = {
        width: 0,
        height: 0,
        scrollTop: 0,
        scrollLeft: 0
    };

    function getDimension() {
        viewport.width = window.innerWidth || documentElement.offsetWidth || 0;
        viewport.height = window.innerHeight || documentElement.offsetHeight || 0;
    }

    function getScroll() {
        viewport.scrollLeft = window.pageXOffset || documentElement.scrollLeft || 0;
        viewport.scrollTop = window.pageYOffset || documentElement.scrollTop || 0;
    }

    getDimension();
    getScroll();

    addEvent(window, 'scroll', function () {
        getScroll();
    });
    addEvent(window, 'resize', function () {
        getDimension();
        getScroll();
    });
}());

(function () {
    var window = this,
        document = window.document,
        $ = window.jQuery,
        $document = $(document),
        msie = $.browser.msie && parseFloat($.browser.version);

    window.MSIE = msie;

    // Internal
    function isChildOf(element, parent) {
        while (element && (element !== document.body)) {
            if (element === parent) {
                return true;
            }
            element = element.parentNode;
        }
        return false;
    }

    function getRandom(min, max){
        return Math.floor(Math.random() * (max - min + 1) + min);
    };

    // Tabs
    $.fn.jsTabs = function (options) {
        var config = $.extend({
                items: 'li',
                selectedItem: 'selected',
                selectedContent: 'tab_content_selected',
                selectedTitle: unescape('%uC120%uD0DD%uB428'),
                selectedIndex: 0,
                random: false,
                imgRegExp: null,
                normalImage: '.gif',
                selectedImage: 'on.gif',
                mouseOver: false,
                roll: false,
                interval: 5000,
                effect: null
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                items = $self.find(config.items),
                imgRegExp = config.imgRegExp,
                eventType = config.mouseOver ? 'click.jsTabs mouseenter.jsTabs' : 'click.jsTabs';

            if ( $.data(self, 'init.jsTabs') ) {
                destroy();
            }

            function init() {
                $.data(self, 'selectedIndex.jsTabs', config.random ? getRandom(0, items.length - 1) : config.selectedIndex);
                $.data(self, 'items.jsTabs', items);

                items.each(function (index) {
                    var item = this,
                        $item = $(item),
                        anchor = item.getElementsByTagName('a')[0],
                        contentId = anchor && anchor.getAttribute('href', 2),
                        content = contentId && (contentId !== '#') && $document.find(contentId),
                        image = item.getElementsByTagName('img')[0];

                    if ( !config.random && $item.hasClass(config.selectedItem) ) {
                        $.data(self, 'selectedIndex.jsTabs', index);
                    }

                    $.data(item, 'index.jsTabs', index);
                    $.data(item, 'image.jsTabs', image);
                    $.data(item, 'content.jsTabs', content);

                    $item.bind({
                        'select.jsTabs': function () {
                            select(index);
                        },
                        'unselect.jsTabs': function () {
                            unselect(index);
                        }
                    });

                    $item.bind(eventType, function (e) {
                        e.preventDefault();
                        $item.trigger('select.jsTabs');
                    });

                    if (config.roll) {
                        $item
                            .bind('mouseenter.jsTabs', function () {
                                stop();
                            })
                            .bind('mouseleave.jsTabs', function () {
                                roll();
                            });
                        content
                            .bind('mouseenter.jsTabs', function () {
                                stop();
                            })
                            .bind('mouseleave.jsTabs', function () {
                                roll();
                            });
                    }
                });

                select( $.data(self, 'selectedIndex.jsTabs') );

                if (config.roll) {
                    roll();
                }

                $.data(self, 'init.jsTabs', true);
            }

            function select(index) {
                unselectAll();

                if ( index < 0 ) {
                    return null;
                }

                var selected = items.eq(index),
                    image = selected.data('image.jsTabs'),
                    content = selected.data('content.jsTabs');

                if (config.selectedImage && image) {
                    var src = image.getAttribute('src');
                    if ( imgRegExp && imgRegExp.exec ) {
                        var exec = imgRegExp.exec(src),
                            match = exec && exec[1];
                        if (match && match !== config.selectedImage) {
                            image.setAttribute( 'src', src.replace(config.normalImage, config.selectedImage) );
                        }
                    } else if ( src.indexOf(config.normalImage) > -1 ) {
                        image.setAttribute( 'src', src.replace(config.normalImage, config.selectedImage) );
                    }
                }

                selected.attr('title', config.selectedTitle);
                selected.addClass(config.selectedItem);
                if (content.length) {
                    content.addClass(config.selectedContent);
                }

                $.data(self, 'selectedIndex.jsTabs', index);
            }

            function unselect(index) {
                var item = items.eq(index),
                    image = item.data('image.jsTabs'),
                    content = item.data('content.jsTabs');

                if (image) {
                    var src = image.getAttribute('src');
                    if ( imgRegExp && imgRegExp.exec ) {
                        var exec = imgRegExp.exec(src),
                            match = exec && exec[1];
                        if (match && match === config.selectedImage) {
                            image.setAttribute( 'src', src.replace(match, config.normalImage) );
                        }
                    } else if ( src.indexOf(config.normalImage) === -1 ) {
                        image.setAttribute( 'src', src.replace(config.selectedImage, config.normalImage) );
                    }
                }

                item.attr('title', '');
                item.removeClass(config.selectedItem);
                if (content) {
                    content.removeClass(config.selectedContent);
                }
            }

            function unselectAll() {
                items.each(function () {
                    $(this).trigger('unselect.jsTabs');
                });
            }

            function roll() {
                var timer = window.setInterval(function () {
                    var index = $.data(self, 'selectedIndex.jsTabs'),
                        next = ++index < items.length ? index : 0;
                    select( next );
                    $.data(self, 'selectedIndex.jsTabs', next);
                }, config.interval);

                $.data(self, 'timer.jsTabs', timer);
            }

            function stop() {
                window.clearInterval( $.data(self, 'timer.jsTabs') );
                $.data(self, 'timer.jsTabs', null);
            }

            init();

            function destroy() {
                items.each(function () {
                    var $item = $(this),
                        content = $.data(this, 'content.jsTabs');
                    $item.removeClass(config.selectedItem);
                    content.removeClass(config.selectedContent);
                    $.data(this, 'content.jsTabs').unbind('.jsTabs');
                    $.removeData(this, 'index.jsTabs');
                    $.removeData(this, 'image.jsTabs');
                    $.removeData(this, 'content.jsTabs');
                    $item.unbind('.jsTabs');
                });
                $self
                    .removeData('selectedIndex.jsTabs')
                    .removeData('items.jsTabs')
                    .removeData('timer.jsTabs');
            }
        });
    };

    // Carousel
    $.fn.jsCarousel = function (options) {
        var config = $.extend({
                viewport: '.viewport',
                itemList: '.item_list',
                item: '.item',
                mode: 'h', // h: 媛�濡�, v: �몃줈
                itemsInGroup: 1,
                prevButton: '.prev',
                nextButton: '.next',
                disabled: 'disabled',
                selectedIndex: -1,
                circular: false,
                animation: false,
                speed: 1000,
                roll: false,
                interval: 3000
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                viewport = $self.find(config.viewport),
                itemList = $self.find(config.itemList),
                items = itemList.find(config.item),
                group = null,
                inViewport = null,
                property = config.mode === 'v' ? 'margin-top' : 'margin-left',
                moveTo = {},
                max = 0,
                prevButton = $self.find(config.prevButton),
                nextButton = $self.find(config.nextButton),
                timer = null;

            if ( $.data(self, 'init.jsCarousel') ) {
                destroy();
            }

            function init() {
                if (items.length <= config.itemsInGroup) {
                    $self.addClass(config.disabled);
                    prevButton.addClass(config.disabled);
                    nextButton.addClass(config.disabled);
                    return null;
                }

                max = getMax();

                if ( !config.circular && parseInt( itemList.css(property) ) === 0 ) {
                    prevButton.addClass(config.disabled);
                }

                inViewport = items.slice(0, config.itemsInGroup);

                if (config.selectedIndex > -1) {
                    inViewport.eq(config.selectedIndex).find('a').eq(0).trigger('select');
                }

                var itemSelector = items.selector;

                prevButton.bind('click.jsCarousel', function (e) {
                    e.preventDefault();

                    prev();
                });
                nextButton.bind('click.jsCarousel', function (e) {
                    e.preventDefault();

                    next();
                });

                if (config.roll) {
                    roll();
                    $self
                        .bind('mouseenter.jsCarousel', function () {
                            stop();
                        })
                        .bind('mouseleave.jsCarousel', function () {
                            roll();
                        });
                }

                $.data(self, 'init.jsCarousel', true);
            }

            function getMax() {
                var len = items.length,
                    itemsInGroup = config.itemsInGroup,
                    remainder = len % itemsInGroup,
                    itemsToCheck = 0;

                if (itemsInGroup === 1) {
                    itemsToCheck = items.slice(0, len - 1);
                } else if (remainder) {
                    itemsToCheck = items.slice(0, len - remainder);
                } else {
                    itemsToCheck = items.slice(0, len - itemsInGroup);
                }

                itemsToCheck.each(function () {
                    var $this = $(this);
                    max += (config.mode === 'v') ? $this.outerHeight(true) : $this.outerWidth(true);
                });

                return max;
            }

            function getGroup(where) {
                where = where || 'first';

                items = itemList.find(config.item);

                var group = null,
                    len = items.length,
                    start = 0;

                if (where === 'last') {
                    group = items.slice(-config.itemsInGroup);
                } else {
                    group = items.slice(0, config.itemsInGroup);
                }

                return group;
            }

            function getDistance(group) {
                if (!group.length) {
                    return null;
                }

                var distance = 0;

                group.each(function () {
                    var $this = $(this);
                    distance += (config.mode === 'v') ? $this.outerHeight(true) : $this.outerWidth(true);
                });

                return distance;
            }

            function setInViewport(where) {
                where = where || 'next';
                var start = inViewport.last().index() + 1;

                if (where === 'prev') {
                    start = inViewport.first().index() - config.itemsInGroup;
                }

                inViewport = items.slice(start, start + config.itemsInGroup);

                if (config.selectedIndex > -1) {
                    inViewport.eq(config.selectedIndex).find('a').eq(0).trigger('select');
                }
            }

            function prev() {
                if ( $.data(self, 'isMoving.jsCarousel') ) {
                    return null;
                }

                var group = getGroup('last'),
                    distance = getDistance(group),
                    destination = config.circular ? 0 : (parseInt( itemList.css(property) ) + distance);

                destination = destination > 0 ? 0 : destination;

                moveTo[property] = destination;

                if (config.circular) {
                    group.prependTo(itemList);
                    if (config.animation) {
                        itemList.css(property, -distance);
                    }
                }

                $.data(self, 'isMoving.jsCarousel', true);

                nextButton.removeClass(config.disabled);

                if (config.animation) {
                    itemList.animate(moveTo, config.speed, function () {
                        $.data(self, 'isMoving.jsCarousel', false);
                        if ( !config.circular && ( parseInt( itemList.css(property) ) === 0 ) ) {
                            prevButton.addClass(config.disabled);
                        }
                        setInViewport('prev');
                    });
                } else {
                    itemList.css(moveTo);
                    $.data(self, 'isMoving.jsCarousel', false);
                    if ( !config.circular && ( parseInt( itemList.css(property) ) === 0 ) ) {
                        prevButton.addClass(config.disabled);
                    }
                    setInViewport('prev');
                }
            }

            function next() {
                if ( $.data(self, 'isMoving.jsCarousel') ) {
                    return null;
                }

                var group = getGroup(),
                    distance = getDistance(group),
                    destination = config.circular ? -distance : (parseInt( itemList.css(property) ) - distance);

                //max = getMax();
                max = max || getMax();

                if ( Math.abs(destination) > max ) {
                    return null;
                }

                moveTo[property] = destination;

                $.data(self, 'isMoving.jsCarousel', true);

                prevButton.removeClass(config.disabled);

                if (config.animation) {
                    itemList.animate(moveTo, config.speed, function () {
                        if (config.circular) {
                            group.appendTo(itemList);
                            itemList.css(property, 0);
                        } else if ( Math.abs( destination - viewport.width() ) > max ) {
                            nextButton.addClass(config.disabled);
                        }
                        $.data(self, 'isMoving.jsCarousel', false);
                        setInViewport();
                    });
                } else {
                    if (config.circular) {
                        group.appendTo(itemList);
                    } else {
                        itemList.css(moveTo);
                        if ( Math.abs( destination - viewport.width() ) > max ) {
                            nextButton.addClass(config.disabled);
                        }
                    }
                    $.data(self, 'isMoving.jsCarousel', false);
                    setInViewport();
                }
            }

            function roll() {
                timer = window.setInterval(function () {
                    next();
                }, config.interval);
            }

            function stop() {
                window.clearInterval(timer);
                timer = null;
            }

            init();

            function destroy() {
                itemList.css(property, 0);
                $self
                    .removeClass(config.disabled)
                    .removeData('isMoving.jsCarousel');
                prevButton
                    .removeClass(config.disabled)
                    .unbind('.jsCarousel');
                nextButton
                    .removeClass(config.disabled)
                    .unbind('.jsCarousel');
            }
        });
    };

    // Carousel - Prev/Next Products
    $.fn.prodCarousel = function (options) {
        var config = $.extend({
                items: 'li',
                prevButton: '.prev',
                prevText: unescape('%uC774%uC804%uC0C1%uD488'),
                nextButton: '.next',
                nextText: unescape('%uB2E4%uC74C%uC0C1%uD488'),
                selectedClass: 'selected_item',
                prevClass: 'prev_item',
                nextClass: 'next_item',
                disabledClass: 'disabled',
                selectedIndex: 1
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                $items = $self.find(config.items),
                len = $items.length,
                $prevButton = $self.find(config.prevButton),
                $nextButton = $self.find(config.nextButton);

            if ( $.data(self, 'init.prodCarousel') ) {
                destroy();
            }

            function init() {
                $.data(self, 'selectedIndex.prodCarousel', config.selectedIndex);

                procCurrent();

                $.data(self, 'init.prodCarousel', true);
            }

            function procCurrent() {
                var selectedIndex = $.data(self, 'selectedIndex.prodCarousel'),
                    $selectedItem = $items.eq(selectedIndex),
                    $prevItem = $selectedItem.prev(),
                    $nextItem = $selectedItem.next();

                $items
                    .removeClass(config.selectedClass)
                    .removeClass(config.prevClass)
                    .removeClass(config.nextClass)
                    .find('span').remove();

                $selectedItem.addClass(config.selectedClass);

                $prevItem
                    .addClass(config.prevClass)
                    .append('<span>' + config.prevText + '</span>');

                $nextItem
                    .addClass(config.nextClass)
                    .append('<span>' + config.nextText + '</span>');

                if (selectedIndex === 0) {
                    $prevButton.addClass(config.disabledClass);
                } else {
                    $prevButton.removeClass(config.disabledClass);
                }
                if (selectedIndex === len - 1) {
                    $nextButton.addClass(config.disabledClass);
                } else {
                    $nextButton.removeClass(config.disabledClass);
                }
            }

            init();

            $self
                .bind('prev.prodCarousel', function () {
                    var selectedIndex = $.data(self, 'selectedIndex.prodCarousel');
                    selectedIndex = --selectedIndex < 0 ? 0 : selectedIndex;
                    $.data(self, 'selectedIndex.prodCarousel', selectedIndex);
                    procCurrent();
                })
                .bind('next.prodCarousel', function () {
                    var selectedIndex = $.data(self, 'selectedIndex.prodCarousel'),
                        len = $items.length;
                    selectedIndex = ++selectedIndex < len ? selectedIndex : len - 1;
                    $.data(self, 'selectedIndex.prodCarousel', selectedIndex);
                    procCurrent();
                });

            $prevButton.bind('click.prodCarousel', function (e) {
                e.preventDefault();
                $self.trigger('prev.prodCarousel');
            });
            $nextButton.bind('click.prodCarousel', function (e) {
                e.preventDefault();
                $self.trigger('next.prodCarousel');
            });

            function destroy() {
                $prevButton.unbind('.prodCarousel');
                $nextButton.unbind('.prodCarousel');
                $self
                    .removeData('selectedIndex.prodCarousel')
                    .removeData('init.prodCarousel');
            }
        });
    };

    // Accordion
    $.fn.jsAccordion = function (options) {
        var config = $.extend({
                title: '.title',
                content: '.content',
                openClass: null,
                openImage: null,
                openAlt: null,
                closeImage: null,
                closeAlt: null,
                closeOthers: true,
                toggle: true,
                selectedIndex: -1
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                $titles = $self.find(config.title);

            if ( $.data(self, 'init.jsAccordion') ) {
                destroy();
            }

            $titles.each(function (i) {
                var $this = $(this),
                    $content = $this.next(config.content);

                if (config.openClass) {
                    $this.removeClass(config.openClass);
                    $content.removeClass(config.openClass);
                } else {
                    $content.css('display', 'none');
                }

                $.data(this, 'index.jsAccordion', i);
                $.data(this, 'content.jsAccordion', $content);
            });

            $titles.bind('open.jsAccordion', function () {
                if ( $.data(this, 'isOpen.jsAccordion') ) {
                    return null;
                }

                var $this = $(this),
                    $content = $.data(this, 'content.jsAccordion'),
                    index = $.data(this, 'index.jsAccordion');

                if (config.closeOthers) {
                    $titles.trigger('close.jsAccordion');
                }

                if (config.openClass) {
                    $this.addClass(config.openClass);
                    $content.addClass(config.openClass);
                } else {
                    $content.css('display', 'block');
                }

                $.data(this, 'isOpen.jsAccordion', true);
                $.data(self, 'selectedIndex.jsAccordion', index);
            });

            $titles.bind('close.jsAccordion', function () {
                if ( !$.data(this, 'isOpen.jsAccordion') ) {
                    return null;
                }

                var $this = $(this),
                    $content = $.data(this, 'content.jsAccordion');

                if (config.openClass) {
                    $this.removeClass(config.openClass);
                    $content.removeClass(config.openClass);
                } else {
                    $content.css('display', 'none');
                }

                $.data(this, 'isOpen.jsAccordion', false);
            });

            $titles.bind('click.jsAccordion', function (e) {
                e.preventDefault();

                if (config.toggle) {
                    var $this = $(this),
                        isOpen = $.data(this, 'isOpen.jsAccordion');

                    if (isOpen) {
                        $this.trigger('close.jsAccordion');
                    } else {
                        $this.trigger('open.jsAccordion');
                    }
                } else {
                    $(this).trigger('open.jsAccordion');
                }
            });

            if (config.selectedIndex > -1) {
                $titles.eq(config.selectedIndex).trigger('open.jsAccordion');
            }

            function destroy() {
                $titles
                    .removeData('index.jsAccordion')
                    .removeData('content.jsAccordion')
                    .removeData('isOpen.jsAccordion');
                $titles.unbind('.jsAccordion');
                $self
                    .removeData('selectedIndex.jsAccordion')
                    .removeData('init.jsAccordion');
            }
        });
    }

    // Accordion - Table
    $.fn.accordionTable = function (options) {
        var config = $.extend({
                title: 'td.subject a',
                content: 'tr.content',
                selected: 'selected',
                hidden: 'hidden',
                selectedIndex: 0
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                titles = $self.find(config.title);

            if ( $.data(self, 'init.accordionTable') ) {
                destroy();
            }

            function init() {
                if (!titles.length) {
                    return null;
                }

                titles.each(function (i) {
                    var $this = $(this),
                        row = ( this.nodeName.toLowerCase() === 'tr' ) ? $this : $this.parents('tr'),
                        content = row.next(config.content).addClass(config.hidden);
                    $.data(this, 'row.accordionTable', row);
                    $.data(this, 'index.accordionTable', i);
                    $.data(this, 'content.accordionTable', content);
                });

                titles.bind('click.accordionTable', function (e) {
                    e.preventDefault();
                    var index = $.data(this, 'index.accordionTable'),
                        content = $.data(this, 'content.accordionTable');
                    if (content.hasClass(config.hidden)) {
                        select(index);
                    } else {
                        unselect(index);
                    }
                });

                $.data(self, 'init.accordionTable', true);
            }

            function select(index) {
                index = index || config.selectedIndex;
                var selected = titles.eq(index),
                    row = selected && selected.data('row.accordionTable'),
                    content = selected && selected.data('content.accordionTable');
                if ( !(content && content.length) ) {
                    return null;
                }
                unselectAll();
                row.addClass(config.selected);
                content.removeClass(config.hidden);
                $.data(self, 'selectedIndex.accordionTable', index);
            }

            function unselect(index) {
                index = index || config.selectedIndex;
                var selected = titles.eq(index),
                    row = selected && selected.data('row.accordionTable'),
                    content = selected && selected.data('content.accordionTable');
                if ( !(content && content.length) ) {
                    return null;
                }
                row.removeClass(config.selected);
                content.addClass(config.hidden);
                $.data(self, 'selectedIndex.accordionTable', null);
            }

            function unselectAll() {
                var i = titles.length;
                while (i--) {
                    unselect(i);
                }
            }

            init();

            function destroy() {
                titles
                    .removeData('index.accordionTable')
                    .removeData('row.accordionTable')
                    .removeData('content.accordionTable')
                    .unbind('.accordionTable');
                $self
                    .removeData('selectedIndex.accordionTable')
                    .removeData('init.accordionTable');
            }
        });
    };

    // Toggle Items
    $.fn.toggleItems = function (options) {
        var config = $.extend({
                items: 'ul.list > li',
                visibleClass: 'visible',
                collapsedClass: 'content_collapsed',
                visibleItems: 10,
                button: '.toggle_button',
                collapseImage: '_close.gif',
                openImage: '_open.gif',
                collapseAlt: unescape('%uB2EB%uAE30'),
                openAlt: unescape('%uB354%uBCF4%uAE30'),
                isCollapsed: true
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                button = $self.find(config.button),
                buttonImage = button.length && button.find('img'),
                items = $self.find(config.items);

            if ( $.data(self, 'init.toggleItems') ) {
                destroy();
            }

            function init() {
                var visible = items.slice(0, config.visibleItems);
                visible.addClass(config.visibleClass);
                if (config.isCollapsed) {
                    $self.addClass(config.collapsedClass);
                }

                $.data(self, 'init.toggleItems', true);
            }

            init();

            button.bind('click.toggleItems', function (e) {
                e.preventDefault();

                if ( $self.hasClass(config.collapsedClass) ) {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace(config.openImage, config.collapseImage);
                            },
                            alt: config.openAlt
                        });
                    }
                    $self.removeClass(config.collapsedClass);
                } else {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace(config.collapseImage, config.openImage);
                            },
                            alt: config.collapseAlt
                        });
                    }
                    $self.addClass(config.collapsedClass);
                }
            });

            function destroy() {
                button.unbind('.toggleItems');
                $.removeData(self, 'init.toggleItems');
            }
        });
    };

    // Image Gallery
    $.fn.imageGallery = function (options) {
        var config = $.extend({
                imageHolder: 'img.image_holder',
                imageLinks: 'ul.small_image_list a',
                selectedClass: 'on',
                selectedIndex: 0,
                mouseOver: true
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                imageHolder = $self.find(config.imageHolder),
                imageLinks = $self.find(config.imageLinks),
                allImgs = imageLinks.find('img'),
                eventType = config.mouseOver ? 'click.imageGallery mouseenter.imageGallery' : 'click.imageGallery';

            if ( $.data(this, 'init.imageGallery') ) {
                destroy();
            }

            if ( !(imageHolder.length && imageLinks.length) ) {
                return null;
            }

            imageLinks.each(function () {
                $.data( this, 'img.imageGallery', $(this).find('img') );
            });

            imageLinks.bind('select.imageGallery', function () {
                var src = this.getAttribute('href');

                allImgs.removeClass(config.selectedClass);

                imageHolder.attr('src', src);
                $.data(this, 'img.imageGallery').addClass(config.selectedClass);
            });

            imageLinks.bind(eventType, function (e) {
                e.preventDefault();

                $(this).trigger('select.imageGallery');
            });

            if ( (config.selectedIndex > -1) && (config.selectedIndex < imageLinks.length) ) {
                imageLinks.eq(config.selectedIndex).trigger('select.imageGallery');
            }

            $.data(this, 'init.imageGallery', true);

            function destroy() {
                imageLinks.unbind('.imageGallery ');
                imageLinks.removeData('img.imageGallery');
                $.removeData(self, 'init.imageGallery');
            }
        });
    };

    // Navigation
    $.fn.nav = function (options) {
        var config = $.extend({
                items: '> li',
                sub: '.nav_sub',
                selectedClass: 'selected'
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                items = $self.find(config.items);

            items.each(function () {
                var item = this,
                    $item = $(item),
                    sub = $item.find(config.sub);

                $.data(item, 'sub.nav', sub);
            });

            items
                .bind('select.nav', function () {
                    items.trigger('unselect.nav');

                    $(this).addClass(config.selectedClass);
                })
                .bind('unselect.nav', function () {
                    $(this).removeClass(config.selectedClass);
                })
                .bind('click.nav mouseenter.nav', function (e) {
                    e.preventDefault();

                    $(this).trigger('select.nav');
                })
                .bind('mouseleave.nav', function (e) {
                    $(this).trigger('unselect.nav');
                });
        });
    };


    // Layer Constructor
    var Layer = window.Layer = function (selector, options) {
        this.config = $.extend({
            openClass: null,
            effect: null,
            afterOpen: null,
            afterClose: null,
            ie6Blocker: false
        }, options);
        this.element = $document.find(selector);
        if ( this.config.ie6Blocker && msie && (msie < 7) ) {
            this.blocker = $('<iframe class="blocker" src="about:blank" frameborder="0" title="鍮덊봽�덉엫"></iframe>').appendTo(this.element);
        }
    };
    Layer.prototype = {
        open: function () {
            var self = this,
                config = self.config,
                element = self.element;
            if (config.effect) {
            } else {
                if (config.openClass) {
                    element.addClass(config.openClass);
                } else {
                    element.css('display', 'block');
                }
                $.data(self, 'isOpen.Layer', true);
                if (config.afterOpen) {
                    config.afterOpen();
                }
            }
        },
        close: function () {
            var self = this,
                config = self.config,
                element = self.element;
            if (config.effect) {
            } else {
                if (config.openClass) {
                    element.removeClass(config.openClass);
                } else {
                    element.css('display', 'none');
                }
                $.data(self, 'isOpen.Layer', false);
                if (config.afterClose) {
                    config.afterClose();
                }
            }
        },
        toggle: function () {
            var self = this,
                config = self.config,
                element = self.element;

            if ( $.data(self, 'isOpen.Layer') ) {
                self.close();
            } else {
                self.open();
            }
        }
    };

    var centerLayer = window.centerLayer = function (layer) {
        var $layer = layer.jquery ? layer : $(layer),
            $window = $(window);

        function centerIt() {
            var width = $layer.width(),
                height = $layer.height(),
                offset = $layer.offset(),
                position = $layer.position(),
                diffTop = position.top - offset.top,
                diffLeft = position.left - offset.left,
                diffWidth = viewport.width - width,
                diffHeight = viewport.height - height,
                top = ( (viewport.height - height) / 2 ) + diffTop + viewport.scrollTop,
                left = ( (viewport.width - width) / 2 ) + diffLeft + viewport.scrollLeft;

            if (width > viewport.width) {
                left = viewport.scrollLeft + diffLeft;
            }
            if (height > viewport.height) {
                top = viewport.scrollTop + diffTop;
            }

            $layer.css({
                'top': top,
                'left': left
            });
        }

        centerIt();

        $window.bind('scroll.centerLayer resize.centerLayer', function () {
            // centerIt();
        });
    }

    // Header - All Category
    function initHeaderAllCategory() {
        var button = $document.find('#headerAllCategoryToggle'),
            buttonImage = button.length && button.find('img'),
            layer = new Layer('#headerAllCategory', {
                afterOpen: function () {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace('.gif', '02.gif');
                            },
                            alt: unescape('%uBAA8%uB4E0%20%uCE74%uD14C%uACE0%uB9AC%20%uB2EB%uAE30')
                        });
                    }
                },
                afterClose: function () {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace('02.gif', '.gif');
                            },
                            alt: unescape('%uBAA8%uB4E0%20%uCE74%uD14C%uACE0%uB9AC%20%uBCF4%uAE30')
                        });
                    }
                },
                ie6Blocker: true
            }),
            element = layer.element;

        if (!element.length) {
            return null;
        }

        button.bind('click.headerAllCategory', function (e) {
            e.preventDefault();

            layer.toggle();
        });

        element.bind('mouseleave.headerAllCategory', function () {
            layer.close();
        });
    }

    // Header - Search
    function initHeaderSearch() {
        var select = $document.find('#mainSearchSelect'),
            layer = new Layer('#main_search_sel', {ie6Blocker: true}),
            element = layer.element;

        if (!element.length) {
            return null;
        }

        select.bind('click.headerSearch', function (e) {
            e.preventDefault();
            layer.toggle();
        });

        element.bind('click.headerSearch mouseleave.headerSearch', function (e) {
            e.preventDefault();
            layer.close();
        });
    }

    // Header - My Lotte
    function initMyLotte() {
        var button = $document.find('#myLotteOverToggle'),
            layer = new Layer('#myLotteOver'),
            element = layer.element,
            items = element.length && element.find('li img');

        if (!element.length) {
            return null;
        }

        button.bind('click.myLotte mouseenter.myLotte', function (e) {
            e.preventDefault();
            layer.open();
        });

        element.bind('click.myLotte mouseleave.myLotte', function () {
            layer.close();
        });

        items.bind({
            'mouseover.myLotte': function () {
                var src = this.getAttribute('src');
                this.setAttribute( 'src', src.replace('_off.gif', '_on.gif') );
            },
            'mouseout.myLotte': function () {
                var src = this.getAttribute('src');
                this.setAttribute( 'src', src.replace('_on.gif', '_off.gif') );
            }
        });
    }

    // History Select
    function initHistorySelect() {
        var selectbox = $document.find('#historySelect'),
            button = selectbox.find('div.select'),
            layer = new Layer('div.layer', {}),
            element = layer.element;

        if (!element.length) {
            return null;
        }

        button.bind('click.historySelect mouseenter.historySelect', function (e) {
            e.preventDefault();
            layer.open();
        });
        button.bind('mouseleave.historySelect', function (e) {
            if ( !isChildOf(e.relatedTarget, element[0]) ) {
                layer.close();
            }
        });

        element.bind('click.historySelect mouseleave.historySelect', function (e) {
            if ( (e.type === 'mouseleave') && isChildOf(e.relatedTarget, button[0]) ) {
                return null;
            }
            layer.close();
        });
    }

    // site
    function initSiteImage() {
        var siteImg = $document.find('#gnbrm_site');
        if (!siteImg) {
            return null;
        }
        $("#gnbrm_site img").hover(function() {
            $(this).attr("src", $(this).attr("src").split("_off.").join("_on."));
        }, function() {
            $(this).attr("src", $(this).attr("src").split("_on.").join("_off."));
        });
    }

    // Wing
    function initWing() {
        var button = $document.find('#passportZoneToggle'),
            buttonImage = button.length && button.find('img'),
            layer = new Layer('#passport_zone', {
                afterOpen: function () {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return this.setAttribute( 'src', src.replace('01.gif', '02.gif') );
                            },
                            alt: '�リ린'
                        });
                        button
                    }
                },
                afterClose: function () {
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return this.setAttribute( 'src', src.replace('02.gif', '01.gif') );
                            },
                            alt: '�닿린'
                        });
                    }
                },
                ie6Blocker: true
            }),
            element = layer.element,
            closeButton = element.length && element.find('.cbtn');

        if (!element.length) {
            return null;
        }

        button.bind('click.wing', function (e) {
            e.preventDefault();
            layer.toggle();
        });

        closeButton.bind('click.wing', function (e) {
            e.preventDefault();
            layer.close();
        });

        $('#fWish').jsCarousel({
            itemList: 'div.viewport > ul',
            item: '> li',
            mode: 'v',
            itemsInGroup: 3,
            animation: true,
            speed: 500
        });
    }
    window.initWing = initWing;

    // Footer - Layers
    function initFooterLayers() {
        var footer = $document.find('#footer'),
            openers = footer.find('.layer_opener');

        openers.each(function () {
            var $this = $(this),
                href = this.getAttribute('href', 2),
                layer = new Layer(href),
                element = layer.element;
            if (!element.length) {
                return null;
            }
            $.data(this, 'layer.footerLayer', layer);
            $this.bind({
                'click.footerLayer': function (e) {
                    e.preventDefault();
                    layer.toggle();
                },
                'mouseenter.footerLayer': function () {
                    layer.open();
                },
                'mouseleave.footerLayer': function () {
                    layer.close();
                }
            });
        });
    }

    // Initialize Global Layers
    function initGlobalLayers() {
        initHeaderAllCategory();
        initHeaderSearch();
        initMyLotte();
        initHistorySelect();
        initWing();
        initFooterLayers();
        initSiteImage();
    }

    // Category View
    var categoryView = window.categoryView = function () {
        var topMenu = $document.find('#topMenu'),
            topMenuTabs = $document.find('#topMenuTabs'),
            divCategoryMenu = $document.find('#divCategoryMenu'),
            categoryViewToggle = $document.find('#categoryViewToggle'),
            collapsedClass = 'category_menu_collapsed';

        topMenuTabs.jsTabs({normalImage: '_off.gif', selectedImage: '_on.gif'});

        categoryViewToggle.bind('click.categoryView', function (e) {
            e.preventDefault();

            if ( divCategoryMenu.hasClass(collapsedClass) ) {
                divCategoryMenu.removeClass(collapsedClass);
            } else {
                divCategoryMenu.addClass(collapsedClass);
            }
        });
    }

    // Initialize Top Menu
    var initTopMenu = window.initTopMenu = function (options) {
        var config = $.extend({
                visibleBlocks: 2,
                visibleItems: 10,
                isCollapsed: true
            }, options),
            topMenu = $document.find('#topMenu'),
            topMenuTabs = $document.find('#topMenuTabs').jsTabs({normalImage: '_off.gif', selectedImage: '.gif'}),
            tabItems = topMenuTabs.data('items.jsTabs'),
            categoryMenu = topMenu.find('div.category_menu'),
            topMenuBrands = $document.find('#topMenuBrands');

        // Initialize Tabs
        if (tabItems) {
            tabItems.each(function () {
                var $this = $(this),
                    content = $.data(this, 'content.jsTabs');

                $this.bind('unselect', function () {
                    content.trigger('collapse');
                });
            });
        }

        // Initializing Category Menu
        categoryMenu.each(function () {
            var $this = $(this),
                toggleButton = $this.find('div.toggle_button'),
                buttonImage = toggleButton.find('img');

            if (config.isCollapsed) {
                $this.addClass('category_menu_collapsed');
            }

            if ( !$this.find('div.category_brands').length ) {
                $this.addClass('brand_search_only');
            }

            $this.bind({
                'open': function () {
                    $this.removeClass('category_menu_collapsed');
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace('_open.gif', '_close.gif');
                            },
                            alt: unescape('%uCE74%uD14C%uACE0%uB9AC%20%uB2EB%uAE30')
                        });
                    }
                },
                'collapse': function () {
                    $this.addClass('category_menu_collapsed');
                    $('html, body').animate({scrollTop: 0}, 500);
                    if (buttonImage.length) {
                        buttonImage.attr({
                            src: function () {
                                var src = this.getAttribute('src');
                                return src.replace('_close.gif', '_open.gif');
                            },
                            alt: unescape('%uCE74%uD14C%uACE0%uB9AC%20%uD3BC%uCCD0%uBCF4%uAE30')
                        });
                    }
                }
            });

            toggleButton.bind('click', function (e) {
                e.preventDefault();

                if ( $this.hasClass('category_menu_collapsed') ) {
                    $this.trigger('open');
                } else {
                    $this.trigger('collapse');
                }
            });
        });

        // Initialize Brands
        function initBrands() {
            var blocks = topMenuBrands.find('div.category_brands div.brand_block');

            blocks.each(function (index) {
                var block = this,
                    $block = $(block),
                    items = $block.find('li');

                if (index < config.visibleBlocks) {
                    $block.addClass('visible');
                    if (config.visibleItems < 0) {
                        items.addClass('visible');
                    } else {
                        items.slice(0, config.visibleItems).addClass('visible');
                    }
                }
            });
        }

        initBrands();

        // Initialize Brand Search
        function initBrandSearch() {
            var brandSearch = topMenuBrands.find('div.brand_search'),
                searchOptions = brandSearch.find('div.search_options'),
                letters = searchOptions.find('a'),
                searchResults = brandSearch.find('div.search_results'),
                closeResults = searchResults.find('div.close');

            letters.bind('click', function (e) {
                e.preventDefault();

                letters.removeClass('selected');
                $(this).addClass('selected');

                searchResults.addClass('search_results_open');
            });

            closeResults.bind('click', function (e) {
                e.preventDefault();
                searchResults.removeClass('search_results_open');
                letters.removeClass('selected');
            });
        }

        initBrandSearch();
    };

    // On Document Ready
    $document.ready(function () {
        initGlobalLayers();
        $('div.produnit').imageGallery();
    });
}());

// Image ON/OFF
function imgOnoff(menuImg){
    if(!document.getElementsByTagName) return false;
    var menuA = document.getElementById(menuImg);
    var lnk = menuA.getElementsByTagName("img");
    for (i=0; i<lnk.length; i++) {
        lnk[i].onmouseover = function() {
            if (this.className != "non"){
                this.src = this.src.replace("_off.gif", "_on.gif");
            }
        }
        lnk[i].onmouseout = function() {
            if (this.className != "non"){
                this.src = this.src.replace("_on.gif", "_off.gif");
            }
        }
    }
}

// Get Style
function getStyle(element, property) {
    var style = null;
    if (window.getComputedStyle) {
        style = window.getComputedStyle(element, null).getPropertyValue(property);
    } else if (element.currentStyle) {
        style = element.currentStyle[property.replace(/\-(.)/g, function (match, letter) {
            return letter.toUpperCase();
        })];
    }
    return style;
}

// Extend Object
function extendObject(original, extended) {
    for (var key in extended) {
        original[key] = extended[key];
    }
    return original;
}

// Open Layer
function openLayer(layerElement, options) {
    var layer = typeof layerElement === 'string' ? document.getElementById(layerElement) : layerElement,
        config = extendObject({
            openClass: null,
            blocker: false,
            center: false,
            parentZIndex: -1
        }, options);

    if (!layer) {
        return null;
    }

    if (window.MSIE && (MSIE < 7) && config.blocker) {
        var iframes = layer.getElementsByTagName('iframe'),
            len = iframes.length,
            i = 0,
            iframe = null,
            blocker = null;

        while (i < len) {
            iframe = iframes[i++];
            if (iframe.className === 'blocker') {
                blocker = iframe;
                break;
            }
        }

        iframe = null;

        if (!blocker) {
            blocker = document.createElement('iframe');
            blocker.className = 'blocker';
            blocker.src = 'about:blank';
            blocker.frameBorder = 0;
            blocker.scrolling = 'no';
            layer.insertBefore(blocker, layer.firstChild);

            iframes = null;
            blocker = null;
        }

        if (config.parentZIndex > -1) {
            var offsetParent = $(layer).offsetParent();
            offsetParent.css('z-index', config.parentZIndex);
        }
    }

    if (config.openClass) {
        var layerClass = ' ' + layer.className + ' ',
            className = ' ' + config.openClass + ' ';
        if ( layerClass.indexOf(className) < 0 ) {
            layer.className += className;
        }
    } else {
        layer.style.display = 'block';
    }

    if (config.center) {
        centerLayer(layer);
    }
}

// Close Layer
function closeLayer(layerElement, options) {
    var layer = typeof layerElement === 'string' ? document.getElementById(layerElement) : layerElement,
        config = extendObject({
            className: null,
            parentZIndex: false
        }, options);
    if (config.className) {
        var layerClass = ' ' + layer.className + ' ',
            className = ' ' + config.className + ' ';
        layer.className = layerClass.replace(className, '');
    } else {
        layer.style.display = 'none';
    }
    if (config.parentZIndex) {
        var offsetParent = $(layer).offsetParent();
        offsetParent.css('z-index', '');
    }
}

// Toggle Layer
function toggleLayer(layerElement, options) {
    options = options || {};
    var layer = typeof layerElement === 'string' ? document.getElementById(layerElement) : layerElement,
        config = extendObject({
            className: null,
            img: null,
            openImg: '_open.gif',
            openAlt: '�닿린',
            closeImg: '_close.gif',
            closeAlt: '�リ린'
        }, options);

    if (config.img) {
        var img = typeof config.img === 'string' ? document.getElementById(config.img) : config.img,
            src = img && img.getAttribute('src');
    }

    if (config.className) {
        var layerClass = ' ' + layer.className + ' ';
        className = ' ' + config.className + ' ';
        if ( layerClass.indexOf(config.className) < 0 ) {
            layer.className += config.className;
            closeImg();
        } else {
            layer.className = layerClass.replace(config.className, '');
            openImg();
        }
    } else {
        var display = getStyle(layer, 'display');
        if (display === 'none') {
            openLayer(layer);
            closeImg();
        } else {
            closeLayer(layer);
            openImg();
        }
    }

    function openImg() {
        if (src) {
            img.setAttribute( 'src', src.replace(config.closeImg, config.openImg) );
            img.setAttribute('alt', config.openAlt);
        }
    }

    function closeImg() {
        if (src) {
            img.setAttribute( 'src', src.replace(config.openImg, config.closeImg) );
            img.setAttribute('alt', config.closeAlt);
        }
    }
}

// LNB Flash
function callbackLink(_link, _target) {
    var link = _link;
    var target = _target;
    if (target == '_top') {
        top.location.href = link;
    } else if (target == '_self') {
        self.location.href = link;
    } else if (target == '_blank') {
        window.open(link,"","");
    } else {
        location.href = link;
    }
    return false;
}

function callbackTabOver(_page){
    if (typeof _isMainGCB == "undefined"){
        var movie;
        if (navigator.appName.indexOf("Microsoft") != -1){
            movie = window["GnbLeft"];
        } else {
            movie =  document["GnbLeft"];
        }

        if(_page == "page_lotte_com")
            movie.height = 799;
        else if(_page == "page_lotte_dept")
            movie.height = 543;
        else if(_page == "page_young")
            movie.height = 543;
        else if(_page == "page_mens")
            movie.height = 543;
        else if(_page == "page_food")
            movie.height = 543;
    }
}

function callbackMouseLeave(_page) {
    var movie;

    if (navigator.appName.indexOf("Microsoft") != -1) {
        movie = window["GnbLeft"];
    } else {
        movie =  document["GnbLeft"];
    }

    if (typeof _isMainGCB != "undefined"){
        if (_isMainGCB === true)
            movie.height = 799;
    }else if (_page == "page_lotte_dept" || _page == "page_young" || _page == "page_mens" || _page == "page_food"){
        movie.height = 543;
    }else{
        movie.height = 799;
    }
    movie.width = 201;
}

function callbackSubMenu() {
    var movie;
    if (navigator.appName.indexOf("Microsoft") != -1) {
        movie = window["GnbLeft"];
    } else {
        movie = document["GnbLeft"];
    }
    movie.width = 299;
    movie.height = 799;
}

function mainLNB(selector) {
    var lnb = $(selector),
        flash = lnb.find('object, embed');
    lnb
        .bind('mouseenter', function () {
            flash.attr('width', '299');
        })
        .bind('mouseleave', function () {
            flash.attr('width', '201');
        });
}


// Large View Layer
function openTabLayer(anchor, selectedIndex) {
    selectedIndex = selectedIndex || 0;

    var $container = $('#container'),
        href = $(anchor).attr('href'),
        layer = $(href),
        tabs = null,
        closeButton = null;

    $container.css('z-index', '10');

    layer.show(0, function () {
        centerLayer(this);
    });

    if ( layer.data('layerTabs') ) {
        tabs = layer.data('layerTabs');
        var items = tabs.find('li');
        items.eq(selectedIndex).trigger('select.jsTabs');
    } else {
        tabs = layer.find('ul.tab-pop');
        layer.data('layerTabs', tabs);
        tabs.jsTabs({normalImage: '_off.gif', selectedImage: '_on.gif', selectedIndex: selectedIndex});
    }

    if ( !layer.data('closeButton') ) {
        closeButton = layer.find('img.pop-close2');
        closeButton.bind('click', function () {
            layer.hide(0, function () {
                $container.css('z-index', '');
            });
        });
        layer.data('closeButton', closeButton);
    }

    initZoomList();
}
function initZoomList(selector) {
    selector = selector || '#lpopLarge';
    var wrapper = $(selector);

    wrapper.imageGallery({imageHolder: 'div.zoom-area img.zoom', imageLinks: 'div.slide-area ul a'});
    wrapper.find('div.zoom-list').jsCarousel({viewport: 'div.slide-area', itemList: 'div.slide-area ul', item: '> li', itemsInGroup: 8, mode: 'v', selectedIndex: 0});
}

function openViewLayer(layer, where) {
    layer = layer.jquery ? layer : $(layer);

    var closeButton = layer.find('img.pop-close2');

    layer
        .bind('open.viewLayer', function () {
            if (where) {
                layer.addClass('layerpop-' + where);
            }
            layer.show(0, function () {
                layer.find('ul.tab-pop').jsTabs({normalImage: '_off.gif', selectedImage: '_on.gif', selectedIndex: 0});
                layer.imageGallery({imageHolder: 'div.zoom-area img.zoom', imageLinks: 'div.slide-area ul a'});
                layer.find('div.zoom-list').jsCarousel({viewport: 'div.slide-area', itemList: 'div.slide-area ul', item: '> li', itemsInGroup: 8, mode: 'v', selectedIndex: 0});
                layer
                    .delegate('img.btn-u', 'mouseover.viewLayer', function () {
                        var src = where ? '/image/onenone/' + where + '/btn_up_on.gif' : '/image/onenone/btn_up_on.gif';
                        changeImage(this, '/image/onenone/btn_up_off.gif', src);
                    })
                    .delegate('img.btn-u', 'mouseout.viewLayer', function () {
                        var src = where ? '/image/onenone/' + where + '/btn_up_on.gif' : '/image/onenone/btn_up_on.gif';
                        changeImage(this, src, '/image/onenone/btn_up_off.gif');
                    })
                    .delegate('img.btn-d', 'mouseover.viewLayer', function () {
                        var src = where ? '/image/onenone/' + where + '/btn_dn_on.gif' : '/image/onenone/btn_dn_on.gif';
                        changeImage(this, '/image/onenone/btn_dn_off.gif', src);
                    })
                    .delegate('img.btn-d', 'mouseout.viewLayer', function () {
                        var src = where ? '/image/onenone/' + where + '/btn_dn_on.gif' : '/image/onenone/btn_dn_on.gif';
                        changeImage(this, src, '/image/onenone/btn_dn_off.gif');
                    });

                centerLayer(layer);
            });
        })
        .bind('close.viewLayer', function () {
            layer.hide(0, function () {
                layer
                    .removeClass('layerpop-dep layerpop-young layerpop-mens')
                    .unbind('.viewLayer')
                    .undelegate('img.btn-u', 'mouseover.viewLayer')
                    .undelegate('img.btn-u', 'mouseout.viewLayer')
                    .undelegate('img.btn-d', 'mouseover.viewLayer')
                    .undelegate('img.btn-d', 'mouseout.viewLayer');
            });
        });

    closeButton.bind('click.viewLayer', function (e) {
        e.preventDefault();

        layer.trigger('close.viewLayer');
    });

    layer.trigger('open.viewLayer');
}

function changeImage(img, src1, src2, alt) {
    var src = img.getAttribute('src');

    img.setAttribute( 'src', src.replace(src1, src2) );
    if (alt) {
        img.setAttribute('alt', alt);
    }
}
//var clear="http://imagedev.lotte.com/lotte/image/common/clear.gif"; //path to clear.gif
//document.write('<script type="text/javascript" id="ct" defer="defer" src="javascript:void(0)"><\/script>');var ct=document.getElementById("ct");ct.onreadystatechange=function(){pngfix()};pngfix=function(){var els=document.getElementsByTagName('*'),ip=/\.png/i,al="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='",i=els.length,uels=new Array(),c=0;while(i-->0){if(els[i].className.match(/unitPng/)){uels[c]=els[i];c++;}}if(uels.length==0)pfx(els);else pfx(uels);function pfx(els){i=els.length;while(i-->0){var el=els[i],es=el.style,elc=el.currentStyle,elb=elc.backgroundImage;if(el.src&&el.src.match(ip)&&!es.filter){es.height=el.height;es.width=el.width;es.filter=al+el.src+"',sizingMethod='crop')";el.src=clear;}else{if(elb.match(ip)){var path=elb.split('"'),rep=(elc.backgroundRepeat=='no-repeat')?'crop':'scale',elkids=el.getElementsByTagName('*'),j=elkids.length;es.filter=al+path[1]+"',sizingMethod='"+rep+"')";es.height=el.clientHeight+'px';es.backgroundImage='none';if(j!=0){if(elc.position!="absolute")es.position='static';while(j-->0)if(!elkids[j].style.position)elkids[j].style.position="relative";}}}}}}




/*** 20120409 ~  : �좊땲�대줈 1.5 -> 2.0 �쒕퉬�� �닿��� �곕Ⅸ 異붽� ***/

(function () {
    var window = this,
        document = window.document,
        $ = window.jQuery,
        $document = $(document),
        msie = $.browser.msie && parseFloat($.browser.version);

    window.MSIE = msie;

    function isChildOf(element, parent) {
        while (element && (element !== document.body)) {
            if (element === parent) {
                return true;
            }
            element = element.parentNode;
        }
        return false;
    }

    getRandom = function(min, max){
        return Math.floor(Math.random() * (max - min + 1) + min);
    };

    getProbRandom = function(prob){
        var newchance = [];
        for(var i = 0; i < prob.length; i++){
            for(var k = 0; k < prob[i]; k++){
                newchance.push(i);
            }
        }
        var _rand = Math.floor(Math.random()*newchance.length);
        return newchance[_rand];
    }

    $.fn.exists = function(){return ($(this).length > 0);};

    $.fn.shuffle = function() {
        return this.each(function(){
        var items = $(this).children();
            return (items.length) ? $(this).html($.shuffle(items)) : this;
        });
    };

    $.shuffle = function(arr) {
        for(
            var j, x, i = arr.length; i;
            j = parseInt(Math.random() * i),
            x = arr[--i], arr[i] = arr[j], arr[j] = x
        );
        return arr;
    };

    // Initialize Main Navigation
    function initHeader() {
        var $headerWrap = $document.find('#headerWrapper'),
            $mainNav = $document.find('#mainNav'),
            $hasSub = $mainNav.find('li.has_sub'),
            $subOpener = $hasSub.find('> a'),
            $mainNavSub = $hasSub.find('> ul'),
            $myPageLayer = $document.find('#myPageLayer'),
            $myPageOpener = $document.find('#userNav li.my_page');
            myPageTabs = $document.find('#myPageLayer ul.js_menu'); //tab異붽�

        // Menu Item Image Change on Mouse Over
        $mainNav.find('img').hover(
            function () {
                var src = this.getAttribute('src');
                this.setAttribute('src', src.replace('_off.gif', '_on.gif'));
            },
            function () {
                var src = this.getAttribute('src');
                this.setAttribute('src', src.replace('_on.gif', '_off.gif'));
            }
        );

        // Sub Menu
        $mainNavSub
            .bind('open', function () {
                $headerWrap.css('z-index', '21');
                $hasSub.find('>a').addClass('open');//20180426추가
                $mainNavSub
                    .data('inAnimation', true)
                    .fadeIn(300, function () {
                        $.data(this, 'inAnimation', false);
                    });
            })
            .bind('close', function () {
                $hasSub.find('>a').removeClass('open');//20180426추가
                $mainNavSub
                    .data('inAnimation', true)
                    .fadeOut(300, function () {
                        $headerWrap.css('z-index', '');
                        $.data(this, 'inAnimation', false);
                    });
            })
            .bind('mouseleave', function (e) {
                if (!isChildOf(e.relatedTarget, $subOpener.get(0))) {
                    $mainNavSub.trigger('close');
                }
            });

        $subOpener
            .bind('click', function (e) {
                e.preventDefault();

                if ($mainNavSub.data('inAnimation')) {
                    return null;
                }

                if ($mainNavSub.is(':visible')) {
                    $mainNavSub.trigger('close');
                } else {
                    $mainNavSub.trigger('open');
                }
            })
            .bind('mouseleave', function (e) {
                if (!isChildOf(e.relatedTarget, $mainNavSub.get(0))) {
                    $mainNavSub.trigger('close');
                }
            });



        // My Page Layer
        $myPageLayer
            .bind('open', function () {
                $headerWrap.css('z-index', '21');
                $myPageLayer.fadeIn(300, function () {
                    $.data(this, 'inAnimation', false);
                });
            })
            .bind('close', function () {
                $myPageLayer.fadeOut(300, function () {
                    $headerWrap.css('z-index', '');
                    $.data(this, 'inAnimation', false);
                });
            })
            .bind('mouseleave', function () {
                $myPageLayer.trigger('close');
            });

        $myPageOpener
            .bind('click mouseenter', function (e) {
                e.preventDefault();

                $myPageLayer.trigger('open');
            });

        $myPageLayer.find('div.close a').bind('click', function (e) {
            e.preventDefault();
            $myPageLayer.trigger('close');
        });

        //mypage tab異붽�
        myPageTabs.jsTabs({normalImage: '', selectedImage: ''});
    }

    // On DOM Ready
    $document.ready(function () {
        initHeader();
    });

    /* --留덉씠�섏씠吏� �곗륫�곷떒 硫붾돱 mypage 留덉슦�� �ㅻ쾭�� �덉씠�큦how 愿��� �ㅽ겕由쏀듃--
    // Tabs
    $.fn.jsTabs = function (options) {
        var config = $.extend({
                items: 'li',
                selectedItem: 'selected',
                selectedContent: 'tab_content_selected',
                selectedTitle: unescape('%uC120%uD0DD%uB428'),
                selectedIndex: 0,
                random: false,
                imgRegExp: null,
                normalImage: '.gif',
                selectedImage: 'on.gif',
                mouseOver: false,
                roll: false,
                interval: 5000,
                effect: null
            }, options);

        return this.each(function () {
            var self = this,
                $self = $(self),
                items = $self.find(config.items),
                imgRegExp = config.imgRegExp,
                eventType = config.mouseOver ? 'click.jsTabs mouseenter.jsTabs' : 'click.jsTabs';

            if ( $.data(self, 'init.jsTabs') ) {
                destroy();
            }

            function init() {
                $.data(self, 'selectedIndex.jsTabs', config.random ? getRandom(0, items.length - 1) : config.selectedIndex);
                $.data(self, 'items.jsTabs', items);

                items.each(function (index) {
                    var item = this,
                        $item = $(item),
                        anchor = item.getElementsByTagName('a')[0],
                        contentId = anchor && anchor.getAttribute('href', 2),
                        content = contentId && (contentId !== '#') && $document.find(contentId),
                        image = item.getElementsByTagName('img')[0];

                    if ( !config.random && $item.hasClass(config.selectedItem) ) {
                        $.data(self, 'selectedIndex.jsTabs', index);
                    }

                    $.data(item, 'index.jsTabs', index);
                    $.data(item, 'image.jsTabs', image);
                    $.data(item, 'content.jsTabs', content);

                    $item.bind({
                        'select.jsTabs': function () {
                            select(index);
                        },
                        'unselect.jsTabs': function () {
                            unselect(index);
                        }
                    });

                    $item.bind(eventType, function (e) {
                        e.preventDefault();
                        $item.trigger('select.jsTabs');
                    });

                    if (config.roll) {
                        $item
                            .bind('mouseenter.jsTabs', function () {
                                stop();
                            })
                            .bind('mouseleave.jsTabs', function () {
                                roll();
                            });
                        content
                            .bind('mouseenter.jsTabs', function () {
                                stop();
                            })
                            .bind('mouseleave.jsTabs', function () {
                                roll();
                            });
                    }
                });

                select( $.data(self, 'selectedIndex.jsTabs') );

                if (config.roll) {
                    roll();
                }

                $.data(self, 'init.jsTabs', true);
            }

            function select(index) {
                unselectAll();

                if ( index < 0 ) {
                    return null;
                }

                var selected = items.eq(index),
                    image = selected.data('image.jsTabs'),
                    content = selected.data('content.jsTabs');

                if (config.selectedImage && image) {
                    var src = image.getAttribute('src');
                    if ( imgRegExp && imgRegExp.exec ) {
                        var exec = imgRegExp.exec(src),
                            match = exec && exec[1];
                        if (match && match !== config.selectedImage) {
                            image.setAttribute( 'src', src.replace(config.normalImage, config.selectedImage) );
                        }
                    } else if ( src.indexOf(config.normalImage) > -1 ) {
                        image.setAttribute( 'src', src.replace(config.normalImage, config.selectedImage) );
                    }
                }

                selected.attr('title', config.selectedTitle);
                selected.addClass(config.selectedItem);
                if (content.length) {
                    content.addClass(config.selectedContent);
                }

                $.data(self, 'selectedIndex.jsTabs', index);
            }

            function unselect(index) {
                var item = items.eq(index),
                    image = item.data('image.jsTabs'),
                    content = item.data('content.jsTabs');

                if (image) {
                    var src = image.getAttribute('src');
                    if ( imgRegExp && imgRegExp.exec ) {
                        var exec = imgRegExp.exec(src),
                            match = exec && exec[1];
                        if (match && match === config.selectedImage) {
                            image.setAttribute( 'src', src.replace(match, config.normalImage) );
                        }
                    } else if ( src.indexOf(config.normalImage) === -1 ) {
                        image.setAttribute( 'src', src.replace(config.selectedImage, config.normalImage) );
                    }
                }

                item.attr('title', '');
                item.removeClass(config.selectedItem);
                if (content) {
                    content.removeClass(config.selectedContent);
                }
            }

            function unselectAll() {
                items.each(function () {
                    $(this).trigger('unselect.jsTabs');
                });
            }

            function roll() {
                var timer = window.setInterval(function () {
                    var index = $.data(self, 'selectedIndex.jsTabs'),
                        next = ++index < items.length ? index : 0;
                    select( next );
                    $.data(self, 'selectedIndex.jsTabs', next);
                }, config.interval);

                $.data(self, 'timer.jsTabs', timer);
            }

            function stop() {
                window.clearInterval( $.data(self, 'timer.jsTabs') );
                $.data(self, 'timer.jsTabs', null);
            }

            init();

            function destroy() {
                items.each(function () {
                    var $item = $(this),
                        content = $.data(this, 'content.jsTabs');
                    $item.removeClass(config.selectedItem);
                    content.removeClass(config.selectedContent);
                    $.data(this, 'content.jsTabs').unbind('.jsTabs');
                    $.removeData(this, 'index.jsTabs');
                    $.removeData(this, 'image.jsTabs');
                    $.removeData(this, 'content.jsTabs');
                    $item.unbind('.jsTabs');
                });
                $self
                    .removeData('selectedIndex.jsTabs')
                    .removeData('items.jsTabs')
                    .removeData('timer.jsTabs');
            }
        });
    };
    */

}());

/**
 * focus layer popup 愿���
 */
function openLayer_target(layerElement, options, target) {
    /**
     * focus layer popup 愿���
     */
    if (!$(target).data("focusLayer"))
        fn_focusLayerEventSetting(target, false);
    $(target).data("openDelay", true); // �대떦�붿냼�� �뺣갑�� ��궎 鍮꾪솢�깊솕

    var layer = typeof layerElement === 'string' ? document.getElementById(layerElement) : layerElement,
        config = extendObject({
            openClass: null,
            blocker: false,
            center: false,
            parentZIndex: -1
        }, options);

    if (!layer) {
        return null;
    }

    if (window.MSIE && (MSIE < 7) && config.blocker) {
        var iframes = layer.getElementsByTagName('iframe'),
            len = iframes.length,
            i = 0,
            iframe = null,
            blocker = null;

        while (i < len) {
            iframe = iframes[i++];
            if (iframe.className === 'blocker') {
                blocker = iframe;
                break;
            }
        }

        iframe = null;

        if (!blocker) {
            blocker = document.createElement('iframe');
            blocker.className = 'blocker';
            blocker.src = 'about:blank';
            blocker.frameBorder = 0;
            blocker.scrolling = 'no';
            layer.insertBefore(blocker, layer.firstChild);

            iframes = null;
            blocker = null;
        }

        if (config.parentZIndex > -1) {
            var offsetParent = $(layer).offsetParent();
            offsetParent.css('z-index', config.parentZIndex);
        }
    }

    if (config.openClass) {
        var layerClass = ' ' + layer.className + ' ',
            className = ' ' + config.openClass + ' ';
        if ( layerClass.indexOf(className) < 0 ) {
            layer.className += className;
        }
    } else {
        layer.style.display = 'block';
    }

    /**
     * focus layer popup 愿���
     */
    target.showLayer(); // �덉씠�� 蹂댁뿬二쇨린 (toggleLayer �몄텧�� 鍮꾪솢�깊솕�� ��궎 �쒖꽦�붾맖)

    if (config.center) {
        centerLayer(layer);
    }

}



/* 20130621 �꾨줈紐낆＜�뚮룄�� */
$.fn.lotteWAtabs = function(options){
    var opts = $.extend({
            listClass : ">ul >li",
            tabClass : ".tabs",
            tabPos: "",
            tabGap: 11,
            rPadding:0,
            contClass : ".cont",
            siblingTabClass : "",
            startIdx : 0,// 泥섏쓬 �쒖옉�� Index (randomFlag媛� fasle �쇰븣留� �곸슜
            eventType : "mouseenter", //mouseenter, click
            tabLinkEnable : true, // �� 留곹겕 �쒖꽦�붿뿬遺�
            intervalTime : 2000,// 濡ㅻ쭅 吏��곗떆媛� (�먮룞濡ㅻ쭅�� true�� 寃쎌슦留� �묐룞)
            animateType : "fade",//none, fade
            animateTime : 500,// �좊땲硫붿씠�� �숈옉�� �쒓컙 �ㅼ젙 (1000 �댄븯媛� �먯뿰�ㅻ윭��)
            rollingFlag : false,// �먮룞濡ㅻ쭅 �щ�
            activeTabClass : "on",// �� �쒖꽦�� class
            randomFlag : false// 泥섏쓬 �쒖옉�� Index �쒕뜡 �щ�
        }, options);

    return this.each(function () {
        var self = this,
            $self = $(this),
            $list = $self.find(opts.listClass),
            $tabs = $self.find(opts.tabClass),
            $conts = $self.find(opts.contClass),
            selectClass = opts.activeTabClass,
            siblingTabClass = opts.siblingTabClass,
            itemContTop = parseInt(($conts.css("top"))?$conts.css("top").replace("px",""):0),
            itemContLeft = parseInt(($conts.css("left"))?$conts.css("left").replace("px",""):0),
            wrapWidth = $self.width(),
            contHeight = $conts.height(),
            beforeIdx = -1,
            cIdx = -1,
            tCnt = $list.length,
            startIdx = (opts.randomFlag) ? Math.floor(Math.random() * tCnt) : opts.startIdx,
            eventType = opts.eventType + ".lotteWAtabs",
            tabLinkEnable = opts.tabLinkEnable,
            rollingInterval = null;

        // Init
        function init() {
            var tn = tCnt-1;
            $tabs.each(function (idx, entry) {
                if( opts.tabPos == 'right'){
                    $(this).css( 'right',tn * opts.tabGap + opts.rPadding);
                }
                tn--;
                $(entry).data("idx", idx);
            });
            $conts.each(function (idx, entry) { $(entry).data("idx", idx); });
            selectIdx(startIdx, true);
            addEvent();
            startInterval();

            if (tCnt < 2) {
                $tabs.hide();
            }
        };

        // Select Next Item
        function next() { selectIdx((cIdx < tCnt - 1)?cIdx + 1:0); };

        // Select Idx Item
        function selectIdx(idx, nowFlag) {
            if (idx == cIdx)
                return;

            if (siblingTabClass != "" && tCnt > 1) {
                if (idx == 0) {
                    $tabs.removeClass(siblingTabClass + "_right " + siblingTabClass + "_left").eq(idx + 1).addClass(siblingTabClass + "_right");
                } else if (idx == tCnt - 1) {
                    $tabs.removeClass(siblingTabClass + "_right " + siblingTabClass + "_left").eq(idx - 1).addClass(siblingTabClass + "_left");
                } else if (tCnt >= 3) {
                    $tabs.removeClass(siblingTabClass + "_right " + siblingTabClass + "_left");
                    $tabs.eq(idx - 1).addClass(siblingTabClass + "_left");
                    $tabs.eq(idx + 1).addClass(siblingTabClass + "_right");
                }
            }

            beforeIdx = cIdx;

            if (beforeIdx > -1)
                $list.eq(beforeIdx).removeClass(selectClass);

            $list.eq(idx).addClass(selectClass);

            if (opts.animateType == "fade") {
                $conts.css({left:-9999, zIndex:0, opacity:0});

                if (nowFlag) {
                    $conts.stop().eq(idx).css({left:0, zIndex:1, opacity:1});
                } else {
                    if (cIdx > -1)
                        $conts.eq(cIdx).css({left:0, zIndex:0, opacity:1});

                    $conts.stop().eq(idx).css({left:0, zIndex:1, opacity:0}).animate({opacity:1}, opts.animateTime, function () { $conts.eq(beforeIdx).css({left:0, zIndex:0, opacity:0}); });
                }
            } else {
                $conts.css({left:-9999, zIndex:0}).eq(idx).css({left:0, zIndex:1});
            }

            cIdx = idx;
        };

        // Start Rolling
        function startInterval() { clearInterval(rollingInterval); if (opts.rollingFlag) rollingInterval = setInterval(next, opts.intervalTime); };

        // Stop Rolling
        function stopInterval() { clearInterval(rollingInterval); };

        // Add Event
        function addEvent() {
            $tabs.bind(eventType, function (event) {
                selectIdx($(this).data("idx"));

                if (eventType == "click")
                    return false;
            });
            $tabs.bind("click.lotteWAtabs", function (event) {
                if (!tabLinkEnable || ($tabs.attr("href").indexOf("#") + "") > -1)
                    return false;
            });
            $tabs.bind("focusin.lotteWAtabs", function (event) { selectIdx($(this).data("idx"), true); });
            $conts.bind("focusin.lotteWAtabs", function (event) { selectIdx($(this).data("idx"), true); });
            $self.bind({
                "mouseenter.lotteWAtabs focusin.lotteWAtabs" : function (event) { stopInterval(); },
                "mouseleave.lotteWAtabs focusout.lotteWAtabs" : function (event) { startInterval(); },
                "changeTab" : function(event, idx, nflag){selectIdx(idx, nflag);}
            });
        };

        init(); /* 珥덇린�� */
    });
};
/* //20130621 �꾨줈紐낆＜�뚮룄�� */
